package edu.mum.cs.cs525.labs.skeleton.lab1_strategy_pattern.behavior;

public interface InterestBehavior {
    double calculateInterest(double balance);
}
