package edu.mum.cs.cs525.labs.skeleton.lab3_decorator_pattern.model;

public class Customer {
	private String name;

	public Customer(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
